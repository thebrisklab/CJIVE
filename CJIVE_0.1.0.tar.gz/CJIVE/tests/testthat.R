library(testthat)
library(CJIVE)

test_check("CJIVE")
